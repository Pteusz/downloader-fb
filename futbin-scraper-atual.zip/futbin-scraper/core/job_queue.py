"""
job_queue.py
────────────
Interface com o dispatcher existente.

Enfileira URLs como jobs no SQLite que o dispatcher já monitora
e aguarda (polling) até o resultado estar disponível.

Nenhuma alteração na tabela `jobs` existente — apenas INSERT/SELECT.
"""

import sqlite3
import time
import logging
from datetime import datetime

log = logging.getLogger(__name__)

DB_PATH      = "/data/scraper.db"
POLL_INTERVAL = 2    # segundos entre polls
MAX_WAIT      = 120  # segundos máximos aguardando um job


def _get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def enqueue(url: str) -> int:
    """
    Insere um job com status 'pending' e retorna o id gerado.
    Se a URL já existe com status 'done', reseta para 'pending' (re-scrape).
    """
    with _get_db() as conn:
        existing = conn.execute(
            "SELECT id, status FROM jobs WHERE url = ?", (url,)
        ).fetchone()

        if existing:
            job_id = existing["id"]
            if existing["status"] == "done":
                conn.execute(
                    "UPDATE jobs SET status='pending', result=NULL, error=NULL, "
                    "retry_count=0, updated=? WHERE id=?",
                    (datetime.utcnow().isoformat(), job_id),
                )
                conn.commit()
                log.debug("Re-enqueued job %d: %s", job_id, url[:60])
            else:
                log.debug("Job %d já está pending: %s", job_id, url[:60])
            return job_id

        cursor = conn.execute(
            "INSERT INTO jobs (url, status, retry_count, created, updated) "
            "VALUES (?, 'pending', 0, ?, ?)",
            (url, datetime.utcnow().isoformat(), datetime.utcnow().isoformat()),
        )
        conn.commit()
        job_id = cursor.lastrowid
        log.debug("Enqueued job %d: %s", job_id, url[:60])
        return job_id


def wait_result(job_id: int, max_wait: int = MAX_WAIT) -> str | None:
    """
    Aguarda o dispatcher completar o job e retorna o HTML (result).
    Retorna None se o job falhar ou o timeout for atingido.
    """
    deadline = time.time() + max_wait
    while time.time() < deadline:
        with _get_db() as conn:
            row = conn.execute(
                "SELECT status, result, error FROM jobs WHERE id = ?", (job_id,)
            ).fetchone()

        if not row:
            log.error("Job %d não encontrado no banco.", job_id)
            return None

        status = row["status"]

        if status == "done":
            if row["result"]:
                return row["result"]
            else:
                log.warning("Job %d concluído com erro: %s", job_id, row["error"])
                return None

        time.sleep(POLL_INTERVAL)

    log.error("Timeout aguardando job %d (max %ds)", job_id, max_wait)
    return None


def fetch(url: str, max_wait: int = MAX_WAIT) -> str | None:
    """
    Atalho: enfileira e aguarda. Retorna o HTML ou None.
    """
    job_id = enqueue(url)
    log.info("Aguardando job %d: %s", job_id, url[:70])
    return wait_result(job_id, max_wait)
