"""
sender.py
─────────
Salva os players em:
  - /data/result.json          (sempre — backward compat)
  - /data/result_{label}.json  (quando label presente — multi-squad)

Ambos são servidos publicamente pela API (nginx) do docker-compose.
"""

import json
import logging
import re
from datetime import datetime, timezone

log = logging.getLogger(__name__)

OUTPUT_PATH = "/data/result.json"
BATCH_SIZE  = 5
_LABEL_RE   = re.compile(r'^[a-zA-Z0-9_-]+$')


def _safe_label(label: str) -> str:
    """Retorna label sanitizado ou vazio se inválido."""
    s = (label or "").strip()
    return s if _LABEL_RE.match(s) else ""


def _build_item(player: dict, sort_index: int, scrape_token: str) -> dict:
    return {
        "type":         "jogador",
        "sort_index":   sort_index,
        "scrape_token": scrape_token,
        "detail_url":   player.get("player_url"),
        "reward_name":  player.get("name"),
        "reward_image": (player.get("images") or {}).get("bg"),
        "sbc": {
            "top_prices": {"console": None, "pc": None, "estimated": None},
            "boxes":      [],
        },
        "player": {
            "player_url":     player.get("player_url"),
            "name":           player.get("name"),
            "rating":         player.get("rating"),
            "position":       player.get("position"),
            "role_plus":      player.get("role_plus"),
            "images":         player.get("images")      or {},
            "stats":          player.get("stats")       or {},
            "info":           player.get("info")        or {},
            "prices":         {"console": None, "pc": None, "estimated": None},
            "card_style_raw": player.get("card_style_raw"),
            "card_css_vars":  player.get("card_css_vars")  or {},
            "alt_sidebar":    player.get("alt_sidebar")    or {},
            "playstyles":     player.get("playstyles")     or {},
            "extra_info":     player.get("extra_info")     or {},
        },
    }


def _write_json(path: str, payload: dict, label: str, total: int) -> bool:
    """Escreve payload em path. Retorna True em sucesso."""
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        log.info("[%s] JSON salvo em %s (%d jogadores)", label, path, total)
        return True
    except Exception as e:
        log.error("Erro ao salvar JSON em %s: %s", path, e)
        return False


def send(
    players:      list[dict],
    scrape_token: str,
    listing_url:  str,
    label:        str = "",
    **kwargs,                  # absorve ajax_url/nonce sem quebrar o caller
) -> dict:
    """
    Monta o payload e salva em /data/result.json (sempre)
    e em /data/result_{label}.json (quando label presente).
    Retorna dict com totais.
    """
    total = len(players)

    items = [
        _build_item(p, p.get("sort_index", i), scrape_token)
        for i, p in enumerate(players)
    ]

    payload = {
        "meta": {
            "timestamp":    datetime.now(timezone.utc).isoformat(),
            "scrape_token": scrape_token,
            "listing_url":  listing_url,
            "label":        label,
            "total":        total,
        },
        "data": items,
    }

    errors = 0

    # 1. Sempre salva o arquivo principal (backward compat)
    if not _write_json(OUTPUT_PATH, payload, label, total):
        errors += total

    # 2. Salva arquivo específico do squad quando label válido
    safe = _safe_label(label)
    if safe:
        if not _write_json(f"/data/result_{safe}.json", payload, label, total):
            errors += 1

    if errors:
        return {"inserted": 0, "updated": 0, "errors": errors}
    return {"inserted": total, "updated": 0, "errors": 0}
