"""
modules/totw.py
───────────────
Módulo TOTW — scrapa todos os jogadores de uma página TOTW do Futbin.

Instanciação via runner.py:
    python runner.py --url "https://www.futbin.com/26/totw/BundesligaTOTS"
    python runner.py --url "https://www.futbin.com/25/totw/WinterWildcards"

Configuração do módulo:
    FETCH_PRICES = False   → preços não são coletados para TOTW
    TYPE         = jogador → todos os itens são jogadores
"""

import logging
import time

from core import job_queue, sender
from core.player_parser import extract_cards, parse_full_player

log = logging.getLogger(__name__)

# ── Configuração do módulo ──────────────────────────────────
FETCH_PRICES  = False
ITEM_TYPE     = "jogador"
NAV_DELAY     = 2.5   # segundos entre fetches de detalhe


def run(listing_url: str, scrape_token: str, ajax_url: str, nonce: str) -> dict:
    """
    Executa o scraping completo de uma página TOTW.

    1. Busca o HTML da listagem
    2. Extrai todos os cards de jogadores
    3. Para cada jogador, busca a página de detalhe
    4. Envia tudo para o WordPress em batches

    Retorna dict com estatísticas finais.
    """
    label = listing_url.rstrip("/").split("/")[-1]   # ex: "BundesligaTOTS"
    log.info("═══ TOTW Scraper | %s ═══", label)

    # ── Fase 1: Listing ─────────────────────────────────────
    log.info("[Fase 1] Buscando listing: %s", listing_url)
    listing_html = job_queue.fetch(listing_url)

    if not listing_html:
        log.error("Não foi possível obter o HTML da listagem. Abortando.")
        return {"error": "listing_failed", "players": 0}

    cards = extract_cards(listing_html)
    total = len(cards)
    log.info("[Fase 1] %d jogadores encontrados", total)

    if total == 0:
        log.warning("Nenhum card encontrado na listagem.")
        return {"error": "no_cards", "players": 0}

    # ── Fase 2: Player detail ────────────────────────────────
    log.info("[Fase 2] Buscando detalhes de %d jogadores...", total)
    players = []

    for i, card in enumerate(cards):
        player_url = card.get("player_url")

        log.info(
            "[%d/%d] %s %s %s",
            i + 1, total,
            card.get("rating", "?"),
            card.get("position", "?"),
            card.get("name", "?"),
        )

        if player_url:
            detail_html = job_queue.fetch(player_url)
            if detail_html:
                player = parse_full_player(
                    html=detail_html,
                    player_url=player_url,
                    fetch_prices=FETCH_PRICES,
                )
            else:
                log.warning("  Detalhe não carregou — usando dados da listagem como fallback")
                player = _listing_fallback(card)
        else:
            log.warning("  player_url não encontrado — usando dados da listagem como fallback")
            player = _listing_fallback(card)

        player["sort_index"] = i
        players.append(player)

        # Delay entre fetches (exceto no último)
        if i < total - 1:
            time.sleep(NAV_DELAY)

    log.info("[Fase 2] %d jogadores processados", len(players))

    # ── Fase 3: Envio ────────────────────────────────────────
    log.info("[Fase 3] Enviando para WordPress...")
    result = sender.send(
        players=players,
        scrape_token=scrape_token,
        listing_url=listing_url,
        ajax_url=ajax_url,
        nonce=nonce,
        label=label,
    )

    log.info("═══ Concluído | %s ═══", label)
    return {**result, "players": len(players)}


# ── Fallback: usa dados básicos da listagem ──────────────────

def _listing_fallback(card: dict) -> dict:
    """
    Quando a página de detalhe não carrega, usa os dados
    que já foram extraídos na fase de listagem como fallback.
    """
    return {
        "player_url":     card.get("player_url"),
        "name":           card.get("name"),
        "rating":         card.get("rating"),
        "position":       card.get("position"),
        "role_plus":      None,
        "images":         card.get("images") or {},
        "stats":          {},
        "info":           {},
        "prices":         {"console": None, "pc": None, "estimated": None},
        "card_style_raw": None,
        "card_css_vars":  {},
        "alt_sidebar":    {},
        "playstyles":     {},
        "extra_info":     {},
    }
