"""
modules/squads.py
─────────────────
Módulo Squads — duas operações:

  scan   → varre https://www.futbin.com/squads e detecta squads novos
  scrape → extrai jogadores de um squad em duas fases:
             Fase 1: squad page (mobile) → extrai URLs /26/player/{id}/{slug}
             Fase 2: para cada URL → fetch da página individual → parse_full_player

Uso via runner.py:
    python runner.py --module squads --op scan   --url "https://www.futbin.com/squads"
    python runner.py --module squads --op scrape --url "https://www.futbin.com/26/totw/UCLWinners"
"""

import json
import logging
import os
import re
import time

from bs4 import BeautifulSoup

from core import job_queue, sender
from core.player_parser import parse_full_player

log = logging.getLogger(__name__)

SQUADS_INDEX_PATH = "/data/squads_index.json"
NAV_DELAY         = 2.5
BASE_URL          = "https://www.futbin.com"


# ════════════════════════════════════════════════════════════
# ÍNDICE
# ════════════════════════════════════════════════════════════

def _load_index() -> list[dict]:
    if not os.path.exists(SQUADS_INDEX_PATH):
        return []
    try:
        with open(SQUADS_INDEX_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        log.warning("Erro ao ler índice: %s — iniciando vazio", e)
        return []


def _save_index(squads: list[dict]):
    try:
        os.makedirs(os.path.dirname(SQUADS_INDEX_PATH), exist_ok=True)
        with open(SQUADS_INDEX_PATH, "w", encoding="utf-8") as f:
            json.dump(squads, f, ensure_ascii=False, indent=2)
        log.info("Índice atualizado: %d squads", len(squads))
    except Exception as e:
        log.error("Erro ao salvar índice: %s", e)


# ════════════════════════════════════════════════════════════
# PARSER DA LISTAGEM /squads
# ════════════════════════════════════════════════════════════

def _parse_squads_listing(html: str) -> list[dict]:
    soup   = BeautifulSoup(html, "lxml")
    squads = []
    seen   = set()

    for a in soup.select("a.squad-box"):
        href = (a.get("href") or "").strip()
        if not href:
            continue
        url = href if href.startswith("http") else BASE_URL + href
        if url in seen:
            continue
        seen.add(url)

        style    = a.get("style") or ""
        bg_match = re.search(r'--background-card:\s*url\(["\']?([^"\')\s]+)["\']?\)', style)
        bg_image = bg_match.group(1) if bg_match else None

        name_el = a.select_one(".squads-header.bold") or a.select_one(".squads-header")
        name    = name_el.get_text(strip=True) if name_el else None

        date_el  = a.select_one(".squads-date")
        date_raw = date_el.get_text(strip=True) if date_el else ""
        created  = date_raw.replace("Created:", "").replace("Created: ", "").strip()

        squads.append({"name": name, "url": url, "created": created, "bg_image": bg_image})

    return squads


# ════════════════════════════════════════════════════════════
# EXTRAÇÃO DE URLs DE JOGADORES (página do squad — mobile)
# ════════════════════════════════════════════════════════════

def _extract_player_urls(html: str) -> list[str]:
    """
    A página do squad em mobile não renderiza playercard-26 completo.
    Extrai apenas os links /26/player/{id}/{slug} presentes no HTML.
    """
    soup  = BeautifulSoup(html, "lxml")
    urls  = []
    seen  = set()
    pat   = re.compile(r"/\d+/player/\d+/")

    # Tenta primeiro dentro de .squad-card (mais preciso)
    containers = soup.select(".squad-card")
    search_in  = containers if containers else [soup]

    for container in search_in:
        for a in container.find_all("a", href=pat):
            href = (a.get("href") or "").strip()
            if not href:
                continue
            url = href if href.startswith("http") else BASE_URL + href
            if url not in seen:
                seen.add(url)
                urls.append(url)

    log.info("_extract_player_urls: %d URLs encontradas", len(urls))
    return urls


# ════════════════════════════════════════════════════════════
# OPERAÇÃO 1: SCAN
# ════════════════════════════════════════════════════════════

def _run_scan(listing_url: str, scrape_token: str, **_kwargs) -> dict:
    log.info("═══ Squads Scan ═══")
    log.info("Buscando: %s", listing_url)

    html = job_queue.fetch(listing_url)
    if not html:
        return {"error": "listing_failed", "total": 0, "new": 0, "squads": []}

    all_squads = _parse_squads_listing(html)
    log.info("%d squads encontrados na página", len(all_squads))

    if not all_squads:
        return {"error": "no_squads", "total": 0, "new": 0, "squads": []}

    known_urls = {s["url"] for s in _load_index()}
    new_squads = [s for s in all_squads if s["url"] not in known_urls]

    log.info("%d squad(s) novo(s) detectado(s):", len(new_squads))
    for s in new_squads:
        log.info("  → [NOVO] %-30s | %s", s["name"], s["created"])

    _save_index(all_squads)

    return {"total": len(all_squads), "new": len(new_squads), "squads": new_squads}


# ════════════════════════════════════════════════════════════
# OPERAÇÃO 2: SCRAPE
# ════════════════════════════════════════════════════════════

def _run_scrape(listing_url: str, scrape_token: str,
                ajax_url: str, nonce: str) -> dict:
    label = listing_url.rstrip("/").split("/")[-1]
    log.info("═══ Squads Scrape | %s ═══", label)

    # ── Fase 1: extrai URLs dos jogadores ────────────────────
    log.info("[Fase 1] Buscando squad (mobile): %s", listing_url)
    listing_html = job_queue.fetch(listing_url)

    if not listing_html:
        return {"error": "listing_failed", "players": 0}

    player_urls = _extract_player_urls(listing_html)
    total       = len(player_urls)
    log.info("[Fase 1] %d URLs de jogadores encontradas", total)

    if total == 0:
        log.warning("Nenhuma URL encontrada — HTML pode ter estrutura diferente.")
        return {"error": "no_players", "players": 0}

    # ── Fase 2: fetch + parse de cada página individual ──────
    log.info("[Fase 2] Buscando página individual de %d jogadores...", total)
    players = []

    for i, player_url in enumerate(player_urls):
        log.info("[%d/%d] %s", i + 1, total, player_url)

        detail_html = job_queue.fetch(player_url)

        if detail_html:
            player = parse_full_player(
                html=detail_html,
                player_url=player_url,
                fetch_prices=False,
            )
        else:
            log.warning("  Falha ao carregar página — pulando jogador")
            player = {"player_url": player_url, "name": None, "rating": None, "position": None}

        player["sort_index"] = i
        players.append(player)

        if i < total - 1:
            time.sleep(NAV_DELAY)

    log.info("[Fase 2] %d jogadores processados", len(players))

    # ── Fase 3: salva ────────────────────────────────────────
    log.info("[Fase 3] Salvando resultado...")
    result = sender.send(
        players=players,
        scrape_token=scrape_token,
        listing_url=listing_url,
        ajax_url=ajax_url,
        nonce=nonce,
        label=label,
    )

    log.info("═══ Concluído | %s ═══", label)
    return {**result, "players": len(players)}


# ════════════════════════════════════════════════════════════
# ENTRY POINT
# ════════════════════════════════════════════════════════════

def run(listing_url: str, scrape_token: str,
        ajax_url: str = None, nonce: str = None,
        op: str = "scan") -> dict:
    if op == "scan":
        return _run_scan(listing_url, scrape_token)
    elif op == "scrape":
        return _run_scrape(listing_url, scrape_token, ajax_url, nonce)
    else:
        log.error("Operação desconhecida: '%s'. Use scan ou scrape.", op)
        return {"error": f"unknown_op:{op}"}
